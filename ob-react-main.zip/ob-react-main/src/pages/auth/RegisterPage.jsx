import React from 'react';

const Registerpage = () => {
    return (
        <div>
            <h1>Register Page</h1>
        </div>
    );
}

export default Registerpage;
