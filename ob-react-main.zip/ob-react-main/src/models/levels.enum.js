export const LEVELS = {
    NORMAL: 'normal',
    URGENT: 'urgent',
    BLOCKING: 'blocking'
}